<h2>WEATHER APP</h2> 
<p>This app consumes openweathermap api to display the weather temperature of your current location. On launch it prompts requesting to access your current location.</p>
<p>The api fetches your current location longitude and latitude if granted access and then display the weather temperature of the location fetched in celcius. It has also feature embedded to convert from celcius to fahrenheit when you click on the temperature.</p>
